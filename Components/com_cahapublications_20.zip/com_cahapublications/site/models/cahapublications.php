<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_content
 *
 * @copyright   Copyright (C) 2005 - 2017 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
jimport('joomla.application.component.modellist');
/**
 * This models supports retrieving a category, the articles associated with the category,
 * sibling, child and parent categories.
 *
 * @since  1.5
 */
class CahaPublicationsModelCahaPublications extends JModelList
{
    /**
     * @var string message
     */
    protected $message;
    
    /**
     * Get the message
     *
     * @return  string  The message to be displayed to the user
     */
    public function getMsg()
    {
        if (!isset($this->message))
        {
            $this->message = 'HelloWorld!';
        }
        
        return $this->message;
    }
    
    function getListQuery()
    {
        $query = parent::getListQuery();
        
        // Request the selected id
        $jinput = JFactory::getApplication()->input;
        $catid     = $jinput->get('catid', 1, 'INT');
            $date = new JDate();
            $now = $date->toSQL();
            $db = JFactory::getDBO();
            $nullDate = $db->getNullDate();
            
            $query = $db->getQuery(true);
            $query
            ->select('p.*')
            ->select($db->quoteName('c.title', 'artTitle'))
            ->from($db->quoteName('#__cahapublications', 'p'))
            ->join('INNER', $db->quoteName('#__content', 'c') . ' ON (' . $db->quoteName('p.title') . ' = ' . $db->quoteName('c.title') . ')')
            ->where($db->quoteName('c.catid') . ' = ' . $catid);
                
                
             return $query;
    }
        
}
