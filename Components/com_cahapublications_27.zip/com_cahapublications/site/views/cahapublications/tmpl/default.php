<?php // no direct access
defined('_JEXEC') or die('Restricted access');
?>
<?php 
    $document = JFactory::getDocument();
    $document->addStyleSheet($this->baseurl.'/media/jui/css/icomoon.css');
    $document->addStyleSheet('media/com_cahapublications/css/cahapublications.css');
?>
<script language="javascript" type="text/javascript">
	
	function tableOrdering( order, dir, task )
	{
		var form = document.adminForm;

		form.filter_order.value 	= order;
		form.filter_order_Dir.value	= dir;
		document.adminForm.submit( task );
	}
	// Handle the slides for the details of each publications based on MooTools v1.2
	window.addEvent('domready', function() {
		var pub_link = $$('a.pub_link');
		var pub_dets = $$('div.pub_details');
		var pub_text = $$('div.pub_text');
		var footnote_link = $$('a.footnote_link'); 
		var pub_footnote = $$('div.pub_footnote');

		pub_text.set('slide',{
			duration:600,
			transition:Fx.Transitions.Back.easeIn
		});
		
		pub_dets.set('slide',{
			duration:900,
			transition:Fx.Transitions.Back.easeIn
		});

		pub_footnote.set('slide',{
			duration:900,
			transition:Fx.Transitions.Back.easeIn
		});

		pub_text.slide('hide');
		pub_dets.slide('hide');
		pub_footnote.slide('hide');

		pub_link.addEvent('click',function(e){
			e.stop();
			var index = pub_link.indexOf(this);
			/* DBH 15-12-11: Comment out the posibility of hiding one div before showing another one
			if(!pub_text.some(function(content,i){
             			var slide = content.get('slide');
             			if(slide.open && i != index){
                 		slide.slideOut().chain(function(){pub_text[index].slide('in')});
                 		return true;
             			}
         		})){
			*/
             			pub_text[index].slide('toggle');
						pub_dets[index].slide('toggle');
         		//}
		});
		footnote_link.addEvent('click',function(e){
			e.stop();
			var index = footnote_link.indexOf(this);
			/* DBH 15-12-11: Comment out the posibility of hiding one div before showing another one
			if(!pub_footnote.some(function(content,i){
             			var slide = content.get('slide');
             			if(slide.open && i != index){
                 		slide.slideOut().chain(function(){pub_footnote[index].slide('in')});
                 		return true;
             			}
         		})){
			*/
             			pub_footnote[index].slide('toggle');
         		//}
		});
	});
	
</script>
<form action="<?php echo JRoute::_('index.php?option=com_cahapublications'); ?>" method="post" id="adminForm" name="adminForm">
	 <h1 class="item-title"><?php echo JText::_('COM_CAHAPUBLICATIONS_BASED_ON_OBSERVATION_AT_CALAR_ALTO'); ?></h1><br />
      <p>
      		<a href="#" class="footnote_link">Footnote to be included in your articles</a>
      		<div class="pub_footnote">
      			<p>The bibliographic data of any publications based on observations at Calar Alto are to be communicated to CAHA as described on our web page:</p>
				<p>
					<a class="moz-txt-link-freetext" href="http://www.caha.es/CAHA/Applications/index.html"></a><a href="http://www.caha.es/CAHA/Applications/index.html">http://www.caha.es/CAHA/Applications/index.html</a>
				</p>
				<p>Publications must contain a footnote as follows:<span style="font-size: 0.8em;">&nbsp;</span></p>
				<p><strong>'Based on observations collected at the Centro Astronómico Hispano Alemán (CAHA) at Calar Alto, operated jointly by the Max-Planck Institut für Astronomie and the Instituto de Astrofísica de Andalucía (CSIC)'.</strong></p>
      		</div>
      </p>
      
<div id="article_search">	
		<strong><?php echo JText::_(' Article Search:').'&nbsp;'; ?></strong>
		<input type="text" name="filter" value="" class="inputbox" onchange="document.adminForm.submit();" />
	
</div>
<table width="100%" border="0" cellspacing="5" cellpadding="5">
<thead>
    <tr>
    	<th> Author</th>
    	<th> Article </th>
    	<th> Year </th>
    </tr>
</thead>
<tfoot>
	<tr>
		<td colspan="3">
			<?php echo $this->pagination->getListFooter(); ?>
			</td>
	</tr>
</tfoot>
<tbody>
    <?php foreach ($this->items as $item) : ?>
    <tr >
    	<td align="left">
    		<?php echo $item->author; ?>
    	</td>
    	<td>
    		<a href="#" class="pub_link">
    			<?php echo $this->escape($item->title); ?>
    		</a>
    	</td>
    	<td>
    		<?php echo $item->year; ?>
    	</td>
    </tr>
    <tr>
    	<td colspan="3">
    		<div id="det_id<?php echo $item->id; ?>" >
    			<div class="pub_text">
    				<?php echo $item->text; ?>
    			</div>
    			<div class="pub_details">
    			<table width="100%" padding="2" class="sectiontableentry1" style="background-color:#dae8f0;text-align:center">
    				<tr style="background-color:#78b7e1;">
    					<td>1st Author</td>
    					<td>Spanish Co/Author</td>
    					<td>German Co/Author</td>
    					<td>CSIC Co/Author</td>
    					<td>MPG Co/Author</td>
    					<td>Telescopes</td>
    					<td>Instruments</td>
    				</tr>
    				<tr>
    					<td><?php echo $item->f_author; ?></td>
    					<td><?php echo $item->s_author; ?></td>
    					<td><?php echo $item->g_author; ?></td>
    					<td><?php echo $item->iaa_author; ?></td>
    					<td><?php echo $item->mpia_author; ?></td>	
    					<td>
    						<?php 
        						$teles = preg_split('/((?<!\\\|\r)\n)|((?<!\\\)\r\n)/', $item->telescopes);
        						
        						echo $item->telescopes;
    						 ?>	
    					</td>
    					<td><?php 
    						//$instrum = explode(",",$item->pinstruments);
    						//$instrum = explode("\n", $item->pinstruments);
    						$instrum = preg_split('/((?<!\\\|\r)\n)|((?<!\\\)\r\n)/', $item->instruments);
    						echo $item->instruments;
    					     ?>
    					</td>
    				</tr>
    			</table>			
    			</div>
    		</div>	 
    			
    	</td>
    </tr>
    <?php endforeach; ?>
</tbody>
</table>

<input type="hidden" name="task" value="" />
</form>
