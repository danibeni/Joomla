<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_content
 *
 * @copyright   Copyright (C) 2005 - 2017 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
jimport('joomla.application.component.modellist');
/**
 * This models supports retrieving a category, the articles associated with the category,
 * sibling, child and parent categories.
 *
 * @since  1.5
 */
class CahaPublicationsModelCahaPublications extends JModelList
{
        
    function getListQuery()
    {
        $query = parent::getListQuery();
        
        // Request the selected id
        //$jinput = JFactory::getApplication()->input;
        //$catid     = $jinput->get('catid', 1, 'INT');
        $db = JFactory::getDBO();
            
        $query = $db->getQuery(true);
        $query
            ->select('*')
            ->from($db->quoteName('#__cahapublications'));
                
        return $query;
    }
        
}
