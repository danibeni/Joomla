<?php // no direct access
defined('_JEXEC') or die('Restricted access');

$listOrder     = $this->escape($this->filter_order);
$listDirn      = $this->escape($this->filter_order_Dir);
?>
<?php 
    $document = JFactory::getDocument();
    $document->addStyleSheet($this->baseurl.'/media/jui/css/icomoon.css');
    $document->addStyleSheet('media/com_cahapublications/css/cahapublications.css');
    $document->addScriptDeclaration('
        jQuery(document).ready(function($) {
                        
			$("#footnote_link").click(function(){
                $("#footnote_text").slideToggle("slow");
			});
            
            $("a.pub_link").click(function(){
                 $(this).closest("tr").next("tr").find(".pub_text").slideToggle("slow", function() {
                    console.log("COMPLETE");
                    $(this).parent().find(".pub_details").slideToggle("slow");
                    
                });                
                
            });
		});
    ');    
?>
<script language="javascript" type="text/javascript">
		
</script>
<form action="<?php echo JRoute::_('index.php?option=com_cahapublications'); ?>" method="post" id="adminForm" name="adminForm">
	 <h1 class="item-title"><?php echo JText::_('COM_CAHAPUBLICATIONS_BASED_ON_OBSERVATION_AT_CALAR_ALTO'); ?></h1><br />
      <p>
      		<a href="javascript:void(0)" id="footnote_link">Footnote to be included in your articles</a>
      		<div id="footnote_text">
      			<p>The bibliographic data of any publications based on observations at Calar Alto are to be communicated to CAHA as described on our web page:</p>
				<p>
					<a class="moz-txt-link-freetext" href="http://www.caha.es/CAHA/Applications/index.html"></a><a href="http://www.caha.es/CAHA/Applications/index.html">http://www.caha.es/CAHA/Applications/index.html</a>
				</p>
				<p>Publications must contain a footnote as follows:<span style="font-size: 0.8em;">&nbsp;</span></p>
				<p><strong>'Based on observations collected at the Centro Astronómico Hispano Alemán (CAHA) at Calar Alto, operated jointly by the Max-Planck Institut für Astronomie and the Instituto de Astrofísica de Andalucía (CSIC)'.</strong></p>
      		</div>
      </p>
      
<div id="article_search">	
		<div class="row-fluid">
		<div class="span6">
			<strong><?php echo JText::_('COM_CAHAPUBLICATIONS_CAHAPUBLICATIONS_FILTER'); ?></strong>
			<?php
				echo JLayoutHelper::render(
					'joomla.searchtools.default',
					array('view' => $this)
				);
			?>
		</div>
	</div>	
</div>
<table width="100%" border="0" cellspacing="5" cellpadding="5">
<thead>
    <tr>
    	<th width="20%"> 
    		<?php echo JHtml::_('grid.sort', 'COM_CAHAPUBLICATIONS_CAHAPUBLICATIONS_AUTHOR', 'author', $listDirn, $listOrder); ?>
    	</th>
    	<th> 
    		<?php echo JHtml::_('grid.sort', 'COM_CAHAPUBLICATIONS_CAHAPUBLICATIONS_TITLE', 'title', $listDirn, $listOrder); ?> 
    	</th>
    	<th width="10%">
    		<?php echo JHtml::_('grid.sort', 'COM_CAHAPUBLICATIONS_CAHAPUBLICATIONS_YEAR', 'year', $listDirn, $listOrder); ?>
    	 </th>
    </tr>
</thead>
<tfoot>
	<tr>
		<td colspan="3">
			<?php echo $this->pagination->getListFooter(); ?>
			</td>
	</tr>
</tfoot>
<tbody>
    <?php foreach ($this->items as $item) : ?>
    <tr >
    	<td align="left">
    		<?php echo $this->escape($item->author); ?>
    	</td>
    	<td>
    		<a href="javascript:void(0)" class="pub_link">
    			<?php echo $this->escape($item->title); ?>
    		</a>
    	</td>
    	<td>
    		<?php echo $item->year; ?>
    	</td>
    </tr>
    <tr>
    	<td colspan="3">
    		<div id="det_id<?php echo $item->id; ?>" >
    			<div class="pub_text">
    				<?php echo $item->text; ?>
    			</div>
    			<div class="pub_details">
    			<table width="100%" padding="2" class="sectiontableentry1" style="background-color:#dae8f0;text-align:center">
    				<tr style="background-color:#78b7e1;">
    					<td>1st Author</td>
    					<td>Spanish Co/Author</td>
    					<td>German Co/Author</td>
    					<td>CSIC Co/Author</td>
    					<td>MPG Co/Author</td>
    					<td>Telescopes</td>
    					<td>Instruments</td>
    				</tr>
    				<tr>
    					<td><?php echo $item->f_author; ?></td>
    					<td><?php echo $item->s_author; ?></td>
    					<td><?php echo $item->g_author; ?></td>
    					<td><?php echo $item->iaa_author; ?></td>
    					<td><?php echo $item->mpia_author; ?></td>	
    					<td>
    						<?php 
        						$teles = preg_split('/((?<!\\\|\r)\n)|((?<!\\\)\r\n)/', $item->telescopes);
        						
        						echo $item->telescopes;
    						 ?>	
    					</td>
    					<td><?php 
    						//$instrum = explode(",",$item->pinstruments);
    						//$instrum = explode("\n", $item->pinstruments);
    						$instrum = preg_split('/((?<!\\\|\r)\n)|((?<!\\\)\r\n)/', $item->instruments);
    						echo $item->instruments;
    					     ?>
    					</td>
    				</tr>
    			</table>			
    			</div>
    		</div>	 
    			
    	</td>
    </tr>
    <?php endforeach; ?>
</tbody>
</table>

<input type="hidden" name="task" value="" />
<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>"/>
<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>"/>
<?php echo JHtml::_('form.token'); ?>
</form>
